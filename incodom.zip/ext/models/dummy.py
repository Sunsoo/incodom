import ext


class Extention(ext.ModelExtention):
    def on_page_update_content(self, page, modified):
        pass
