Add template for specific schema itemtype in this directory. For example,
if you add ``Book.html``, this file will be used to render a wiki page whose
``.schema`` is ``Book``.
